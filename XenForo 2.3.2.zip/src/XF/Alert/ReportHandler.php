<?php

namespace XF\Alert;

class ReportHandler extends AbstractHandler
{
}
