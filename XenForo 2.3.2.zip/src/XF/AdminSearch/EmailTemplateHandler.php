<?php

namespace XF\AdminSearch;

class EmailTemplateHandler extends PublicTemplateHandler
{
	protected function getSearchTemplateType()
	{
		return 'email';
	}
}
